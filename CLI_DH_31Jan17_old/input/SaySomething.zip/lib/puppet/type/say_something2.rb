Puppet::Type.newtype(:say_something2) do
  ensurable
  newparam(:message) do
    isnamevar
  end
end