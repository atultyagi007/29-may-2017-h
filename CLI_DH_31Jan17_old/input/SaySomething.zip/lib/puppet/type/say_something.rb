Puppet::Type.newtype(:say_something) do
  ensurable
  newparam(:message) do
    isnamevar
  end
end