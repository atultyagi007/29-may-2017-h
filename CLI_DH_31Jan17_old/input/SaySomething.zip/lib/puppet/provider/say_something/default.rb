Puppet::Type.type(:say_something).provide(:default) do
  def exists?
    false
  end
  def create
    Puppet.info("Inside resource :say_something, message: #{resource[:message]}")
  end
  def destroy

  end
end