Puppet::Type.type(:say_something2).provide(:default) do

  def exists?
    false
  end
  def create
    Puppet.info("Inside resource :say_something2, message: #{resource[:message]}")
  end
  def destroy

  end
end