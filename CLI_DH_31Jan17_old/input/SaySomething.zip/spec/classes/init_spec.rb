require 'spec_helper'
describe 'asm_test' do

  context 'with defaults for all parameters' do
    it { should contain_class('asm_test') }
  end
end
